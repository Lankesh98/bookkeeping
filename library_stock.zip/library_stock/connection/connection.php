<?php
$con=mysqli_connect("localhost","root","","library_stock");
?>