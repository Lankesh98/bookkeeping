<?php

$fname=$_POST['fname'];
$lname=$_POST['lname'];
$uname=$_POST['uname'];
$nic=$_POST['nic'];
$email=$_POST['email'];
$pass=$_POST['pass'];
$utype=$_POST['utype'];


include_once '../../../connection/connection.php';

$sql="INSERT INTO users( fname, lname, uname, nic, email, pass, utype) VALUES ('".$fname."','".$lname."','".$uname."','".$nic."','".$email."','".$pass."','".$utype."')";

$query=mysqli_query($con,$sql);

if ($query) {
	?>

		<script>
			window.location.href="../messages/insert-success.php";
		</script>

	<?php
}
else{
	echo "Sorry, Something gone wrong";
}








?>