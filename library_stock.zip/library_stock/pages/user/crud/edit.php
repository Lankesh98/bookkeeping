<?php


$uid=$_POST['uid'];
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$uname=$_POST['uname'];
$nic=$_POST['nic'];
$email=$_POST['email'];
$pass=$_POST['pass'];
$utype=$_POST['utype'];




include '../../../connection/connection.php';

$sql=" UPDATE users SET fname='".$fname."', lname='".$lname."', uname='".$uname."', nic='".$nic."', email='".$email."', pass='".$pass."', utype ='".$utype."'  WHERE u_id = '".$uid."' ";

$query=mysqli_query($con,$sql);

if ($query) {
	?>

		<script>
			window.location.href="../messages/update-success.php";
		</script>

	<?php
}
else{
	echo "Sorry, Something gone wrong";
}








?>