<?php
include_once "../../connection/connection.php";
session_start();
if( $_SESSION['email']=='')
{
	header("location:index.php");
}
else
{
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php
include_once "../../layers/head.php";
?>
</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <?php
      include_once "../../layers/sidebar.php";
    ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
       <?php
          include_once "../../layers/topbar.php";
       ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
        
          <!-- Page Heading -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Users Details</h6>
            </div>
            <form method='post'>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>First Name</th>
                      <th>Last Name</th>
                      <th>User Name</th>
                      <th>NIC</th>
                      <th>Email</th>
                      <th>Password</th>
                      <th>Action Links</th>
                    </tr>
                  </thead>
                  <tbody>
            <?php
            include_once "../../connection/connection.php";

            $sql = "SELECT * FROM users ";
            $result = mysqli_query($con,$sql);


        
                  while ($row = mysqli_fetch_assoc($result)) 
                     { 
                                             
                      
                  ?>
                    <tr>
                      <td><?php echo $row['fname']; ?></td>
                      <td><?php echo $row['lname']; ?></td>
                      <td><?php echo $row['uname']; ?></td>
                      <td><?php echo $row['nic']; ?></td>
                      <td><?php echo $row['email']; ?></td>
                      <td><?php echo $row['pass']; ?></td>
                      <td>
                          <a href="crud/delete.php?id=<?php echo $row['u_id']; ?>"class="btn btn-danger" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash"></i></a>
                          <a href="view-single.php?id=<?php echo $row['u_id']; ?>" class="btn btn-primary"><i class="fa fa-eye"></i></a>
                          <a href="edit.php?id=<?php echo $row['u_id']; ?>" class="btn btn-secondary" ><i class="fa fa-edit"></i></a>

                        </td>
                    </tr>
                    
                    <?php
                     }
                    ?>

                  </tbody>
                    </form>

                </table>

              </div>
            </div>
          </div>

        </div>
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->
                    </div>
      <!-- Footer -->
      <?php
      include_once "../../layers/footer.php";
     ?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->
   
  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  

  <?php
  include_once "../../layers/logoutmodal.php";

  include_once "../../layers/scripts.php";
  ?>

</body>

</html>

<?php
}
?>