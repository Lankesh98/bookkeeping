<?php
include_once "../../connection/connection.php";
session_start();
if( $_SESSION['email']=='')
{
	header("location:index.php");
}
else
{
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php
include_once "../../layers/head.php";
?>
</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <?php
      include_once "../../layers/sidebar.php";
    ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
       <?php
          include_once "../../layers/topbar.php";
       ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
        <?php
            include_once "../../connection/connection.php";

            $sql = "SELECT * FROM category ";
            $result = mysqli_query($con,$sql);
            $row = mysqli_num_rows($result);


        ?>
          <!-- Page Heading -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Category Details</h6>
            </div>

            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Category ID</th>
                      <th>Category Name</th>
                      <th>Action Links</th>


                    </tr>
                  </thead>
                  <tbody>
                  <form action="" method='post'>
                  <?php 
                  while ($row = mysqli_fetch_assoc($result)) 
                     { 
                        $cid = $row['cat_id'];
                        $cname = $row['cat_name'];
   
                  ?>
                    <tr>
                      <td><?php echo $cid ?></td>
                      <td><?php echo $cname ?></td>
                      <td>

                          <span id="myBtn" class="btn btn-secondary" data-toggle="modal" onclick="EditCat('<?php echo $cid;?>','<?php echo $cname;?>')"><i class="fa fa-edit"></i><a href="javascript:void(0)"></a></span>
                          <span id="myBtn2" class="btn btn-primary" data-toggle="modal" onclick="ViewCat('<?php echo $cid;?>','<?php echo $cname;?>')"><i class="fa fa-eye"></i><a href="javascript:void(0)"></a></span>
                          <a href="crud/delete.php?id=<?php echo $bid ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash"></i></a>

                      </td>
                    </tr>

                   
                    <?php
                     }
                    ?>
                  </form>
                  </tbody>

                </table>

              </div>
            </div>
          </div>

        </div>
        </div>
        <!-- /.container-fluid -->

      </div>
                    </div>
  <script>
    function ConfirmDelete()
    {
      confirm("Are you sure you want to delete this category?");
      if (confirm == TRUE) {
        parent.location='<?php echo "crud/delete.php?id=" . $bid ?>';
      }
    }
  </script>
      <!-- End of Main Content -->

      <!-- Footer -->
      <?php
     include_once "../../layers/footer.php";
     ?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->
    
  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>






  <?php
  include_once "../../layers/logoutmodal.php";
  include_once "../../layers/scripts.php";
  ?>

</body>

</html>
<?php
}
?>