<?php


$cid=$_POST['cat_id'];
$cname=$_POST['cname'];




include '../../../connection/connection.php';

$sql=" UPDATE category SET cat_name='".$cname."' WHERE cat_id = '".$cid."' ";

$query=mysqli_query($con,$sql);

if ($query) {
	?>

		<script>
			window.location.href="../messages/update-success.php";
		</script>

	<?php
}
else{
	echo "Sorry, Something gone wrong";
}








?>