<?php

$cname=$_POST['cname'];


include_once '../../../connection/connection.php';

$sql="INSERT INTO category (cat_name) VALUES ('".$cname."')";

$query=mysqli_query($con,$sql);

if ($query) {
	?>

		<script>
			window.location.href="../messages/insert-success.php";
		</script>

	<?php
}
else{
	echo "Sorry, Something gone wrong";
}








?>