 
 <?php
include_once "../../connection/connection.php";
session_start();
if( $_SESSION['email']=='')
{
	header("location:index.php");
}
else
{
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php
include_once "../../layers/head.php";
?>
</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <?php
      include_once "../../layers/sidebar.php";
    ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
       <?php
          include_once "../../layers/topbar.php";
       ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
        
        <?php
 
    $Name = $_POST['search'];
  
 //Search query.
  
    $sql = "SELECT * FROM books
    INNER JOIN author ON author.aut_id = books.aut_id WHERE b_name LIKE '%$Name%' OR author LIKE '%$Name%'";
  
 //Query execution
  
    $result = mysqli_query($con, $sql);
  
  
 ?>
          <!-- Page Heading -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Book Details</h6>
            </div>

            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Book Title</th>
                      <th>Book Author</th>
                      <th>Book Price</th>
                      <th>Book Image</th>
                      <th>Action Links</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php 
                    //Fetching result from the database.
  
                    while ($row = mysqli_fetch_array($result)) 
                    {
                  
                    ?>                   
                    <tr>
                      <td><?php echo $row['b_name']; ?></td>
                      <td><?php echo $row['author']; ?></td>
                      <td>Rs. <?php echo $row['price']; ?></td>
                      <td><img src="../books/crud/upload/<?php echo $row['image'] ?>" style="width:100px; height:200px;" ></td>
                      <td>
                          <a id="<?php echo $url ?>/pages/books/crud/delete.php?id=<?php echo $row['b_id'] ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash" ></i></a>
                          <a href="<?php echo $url ?>/pages/books/view-single.php?id=<?php echo $row['b_id']; ?>" class="btn btn-primary"><i class="fa fa-eye"></i></a>
                          <a href="<?php echo $url ?>/pages/books/edit.php?id=<?php echo $row['b_id']; ?>" class="btn btn-secondary" ><i class="fa fa-edit"></i></a>
                         
                        </td>
                    </tr>
                    
                    <?php
                     }
                    ?>

                  </tbody>

                </table>

              </div>
            </div>
          </div>

        </div>
        </div>
        <!-- /.container-fluid -->
        <script>
    function ConfirmDelete()
    {
      confirm("Are you sure you want to delete this category?");
      if (confirm == FALSE) {
        window.location = "index.php";
      }
    }
  </script>
      </div>
      <!-- End of Main Content -->
                    </div>
      <!-- Footer -->
      <?php
      include_once "../../layers/footer.php";
     ?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->
   
  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  

  <?php
  include_once "../../layers/logoutmodal.php";

  include_once "../../layers/scripts.php";
  ?>

</body>

</html>

<?php
}
?>