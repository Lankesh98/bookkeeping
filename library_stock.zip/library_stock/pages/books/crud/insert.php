<?php

include '../../../connection/connection.php';


$bname=$_POST['bname'];
$aname=$_POST['aname'];
$yop=$_POST['yop'];
$price=$_POST['price'];
$yop=$_POST['yop'];
$isbn=$_POST['isbn'];
$medium=$_POST['medium'];
$cname=$_POST['cname'];

$name = $_FILES['file']['name'];
$sql = "SELECT * FROM books WHERE isbn = '".$isbn."'";
$res = mysqli_query($con,$sql);
$row = mysqli_num_rows($res);
if ($row == 1) {
	echo "<script>alert('Your ISBN is Not valid');</script>";
	echo "<script>window.location='../addbooks.php';</script>";
}

else {
$target_dir = "upload/";
$target_file = $target_dir . basename($_FILES["file"]["name"]);

// Select file type
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

// Valid file extensions
$extensions_arr = array("jpg","jpeg","png","gif");

// Check extension
if( in_array($imageFileType,$extensions_arr) ){

   // Insert record
   $query = "INSERT INTO books (b_name, aut_id, cat_id, YoP, price, isbn, medium, image) values('".$bname."','".$aname."','".$cname."','".$yop."','".$price."','".$isbn."','".$medium."','".$name."')";
   $result = mysqli_query($con,$query);

   // Upload file
   move_uploaded_file($_FILES['file']['tmp_name'],$target_dir.$name);

}

if ($result == TRUE) {
	?>

		<script>
			window.location.href="../messages/insert-success.php";
		</script>

	<?php
}
else{
	echo "Sorry, Something gone wrong";
	echo "<script>window.location='../addbooks.php';</script>";

	
}

}






?>