<?php

$id=$_GET['id'];

include '../../../connection/connection.php';

$sql="DELETE FROM books WHERE b_id='$id'";

$query=mysqli_query($con,$sql);

if ($query) {
	?>
		<script>
			window.location.href='../messages/delete-success.php'
		</script>

	<?php
}
else{
	echo "Something Gone Wrong";
}



?>