<?php

include '../../../connection/connection.php';

$id = $_POST['id'];
$bname=$_POST['bname'];
$aname=$_POST['aname'];
$yop=$_POST['yop'];
$price=$_POST['price'];
$yop=$_POST['yop'];
$isbn=$_POST['isbn'];
$medium=$_POST['medium'];
$cname=$_POST['cname'];

$name = $_FILES['file']['name'];

if ($name =="")
{
    $query = "UPDATE books SET b_name ='".$bname."', aut_id ='".$aname."', cat_id ='".$cname."', YoP ='".$yop."', price ='".$price."', isbn ='".$isbn."', medium ='".$medium."' WHERE b_id = '".$id."'";
    $result = mysqli_query($con,$query);
 
 
 if ($result == TRUE) {
     ?>
 
         <script>
             window.location.href="../messages/insert-success.php";
         </script>
 
     <?php
 }
 else{
     echo "Sorry, Something gone wrong";
 }
 
}
else
{
$target_dir = "upload/";
$target_file = $target_dir . basename($_FILES["file"]["name"]);

// Select file type
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

// Valid file extensions
$extensions_arr = array("jpg","jpeg","png","gif");

// Check extension
if( in_array($imageFileType,$extensions_arr) ){

   // Insert record
   $query = "UPDATE books SET b_name ='".$bname."', aut_id ='".$aname."', cat_id ='".$cname."', YoP ='".$yop."', price ='".$price."', isbn ='".$isbn."', medium ='".$medium."', image='".$name."' WHERE b_id = '".$id."' ";
   $result = mysqli_query($con,$query);

   // Upload file
   move_uploaded_file($_FILES['file']['tmp_name'],$target_dir.$name);

}

if ($result == TRUE) {
	?>

		<script>
			window.location.href="../messages/update-success.php";
		</script>

	<?php
}
else{
	echo "Sorry, Something gone wrong";
}

}






?>