<?php
include_once "../../connection/connection.php";
session_start();
if( $_SESSION['email']=='')
{
	header("location:index.php");
}
else
{
?>

<?php

  $id=$_GET['id'];

  $sql="SELECT * FROM books 
  INNER JOIN author on author.aut_id = books.aut_id 
  INNER JOIN category on category.cat_id = books.cat_id WHERE b_id='$id'";

  $query=mysqli_query($con,$sql);

  while ($row=mysqli_fetch_array($query)) {

    $bname=$row['b_name'];
    $price=$row['price'];
    $yop=$row['YoP'];
    $isbn=$row['isbn'];
    $medium=$row['medium'];
    $img=$row['image'];
    $aname=$row['author'];
    $cname=$row['cat_name'];
    $aid = $row['aut_id'];
    $cid = $row ['cat_id'];
    # code...
  }




?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php
include_once "../../layers/head.php";
?>
</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <?php
      include_once "../../layers/sidebar.php";
    ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
       <?php
          include_once "../../layers/topbar.php";
       ?>
        <!-- End of Topbar -->

        <script>
          $("#yop").datepicker({
              format: "yyyy",
              viewMode: "years", 
              minViewMode: "years"
          });
        </script>
        <!-- Begin Page Content -->
        <div class="container-fluid">
        <div class="row">

<div class="col-12 col-sm-12 col-md-12 col-lg-10 col-xl-10 offset-0 offset-sm-0 offset-md-0 offset-lg-1 offset-xl-1">

  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">
        Edit Book Details
      </h6>
    </div>

    <div class="card-body">
      
     <form id="insertBook" action="crud/edit.php" method="POST" enctype='multipart/form-data'>
       
       <div class="row">
         
       <input type="hidden" value="<?php echo $id; ?>" name="id">
          <div class="col-12 col-md-6">                      
            <div class="form-group">
              <label for="">Book Title</label>
              <input 
                type="text" 
                name="bname"                          
                class="form-control"
                required=""
                value = "<?php echo $bname; ?>" 
              >
            </div>
          </div>

          <div class="col-12 col-md-6">                      
            <div class="form-group">
              <label for="">Author Name</label>
              <select 
                type="text" 
                name="aname"                          
                class="form-control"
                required="" 
              >
              <option value = "<?php echo $aid; ?>"><?php echo $aname; ?></option>
            
              <?php
                include_once "../../coection/connection.php";
                $sql = "SELECT * FROM author ";
                $result = mysqli_query($con,$sql);
                $row = mysqli_num_rows($result);

                while ($array = mysqli_fetch_assoc($result)) {
                    ?>
                <option value="<?php echo $array['aut_id']?>"><?php echo $array['author']?></option>
                <?php
                }
                ?>
              ?>
              </select>
            </div>
          </div>

          <div class="col-12 col-md-6">                      
            <div class="form-group">
              <label for="">Category Name</label>
              <select 
                type="text" 
                name="cname"                          
                class="form-control"
                required="" 
              >
              <option value = "<?php echo $cid; ?>" ><?php echo $cname; ?></option>
              <?php
                include_once "../../coection/connection.php";
                $sql = "SELECT * FROM category ";
                $result = mysqli_query($con,$sql);
                $row = mysqli_num_rows($result);

                while ($array = mysqli_fetch_assoc($result)) {
                    ?>
                <option value="<?php echo $array['cat_id']?>"><?php echo $array['cat_name']?></option>
                <?php
                }
                ?>
              ?>
              </select>
            </div>
          </div>

          <div class="col-12 col-md-6">                      
            <div class="form-group">
              <label for="">Year of Publish</label>
              <div class='input-group date' >                                             
              <select class="form-control" name="yop">
                  <option value = "<?php echo $yop; ?>"><?php echo $yop; ?></option>
                <?php
                  for ($year = (int)date('Y'); 1900 <= $year; $year--): ?>
                    <option value="<?=$year;?>"><?=$year;?></option>
                <?php endfor; ?>
              </select>
              </div>
            </div> 
          </div>

          <div class="col-12 col-md-6">                      
            <div class="form-group">
              <label for="">Price</label>
              <input 
                type="text" 
                name="price"                          
                class="form-control"
                required="number_format"
                value = "<?php echo $price; ?>"
              >
            </div>
          </div>



          <div class="col-12 col-md-6">                      
            <div class="form-group">
              <label for="">ISBN</label>
              <input 
                type="text" 
                name="isbn"                          
                class="form-control"
                required="" 
                value = "<?php echo $isbn; ?>"
              >
            </div>
          </div>

          <div class="col-12 col-md-6">                      
            <div class="form-group">
              <label for="">Medium</label>
              <SELECT 
                type="text" 
                name="medium"                          
                class="form-control"
                required="" 
              >
              <option value="<?php echo $medium ?>"><?php echo $medium ?></option>
              <option value="English">English</option>
              <option value="Tamil">Tamil</option>
              <option value="Sinhala">Sinhala</option>
              </SELECT>
            </div>
          </div>

          <div class="col-12 col-md-6">                      
            <div class="form-group">
              <label for="">Image</label>
              <input 
                type="file" 
                name="file"                          
                class="form-control"
                value = "<?php echo $img ?>"
              >
            </div>
          </div>          

          <div class="col-12">
            <div class="form-group">
              <input 
                type="submit" 
                class="form-control btn btn-primary"
                value="SEND" 
              >
            </div>
          </div>

       </div>

     </form>


    </div>

  </div>

</div>

</div>

<script src="js/yearpicker.js"></script>
    <script>
      $(document).ready(function() {
        $(".yearpicker").yearpicker({
          year: 2020,
          startYear: 1950,
          endYear: 2050
        });
      });
    </script>

       
            </div>
          </div>

        </div>
        </div>
        <!-- /.container-fluid -->

      </div>
                    </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <?php
     include_once "../../layers/footer.php";
     ?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->
    
  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  



  <?php
  include_once "../../layers/logoutmodal.php";

  include_once "../../layers/scripts.php";
  ?>

</body>

</html>

<?php
}
?>